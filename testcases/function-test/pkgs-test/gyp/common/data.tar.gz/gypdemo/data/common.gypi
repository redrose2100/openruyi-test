{
  'defines': ['NDEBUG'],  # defines does not contain pathnames
}
