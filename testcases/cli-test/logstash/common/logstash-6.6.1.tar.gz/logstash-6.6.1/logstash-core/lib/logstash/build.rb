# encoding: utf-8
BUILD_INFO = {"build_date"=>"2019-02-13T17:56:32+00:00", "build_sha"=>"a9af53240d1a533f41f41107dbf2ca68fe4c4e1e", "build_snapshot"=>false}