module.exports = function(grunt) {
  grunt.registerTask('webget', function() {
    grunt.file.write('FILE.md', "bbbbbbbb");
  });
};
