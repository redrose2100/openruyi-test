#!/bin/bash
curvetun -s -p 6666 -u -D
ifconfig curves0 up
ifconfig curves0 10.0.0.1/24
