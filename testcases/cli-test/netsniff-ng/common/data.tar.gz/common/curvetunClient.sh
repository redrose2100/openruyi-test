#!/bin/bash
serverInfo=$1
echo $serverInfo > ~/.curvetun/servers
