keyvalue=$(curvetun -x | sed -n "3p" | awk -F ';' '{print $2}')
echo "tunserver=${keyvalue}" > /tmp/curvetunServer.info
