expect << EOF
    spawn curvetun -k
    expect {
        "Username: " {
            send "tunserver\\r"
        }
    }
    expect eof
EOF

