#!/bin/bash
clientinfo=$1
echo $clientinfo > ~/.curvetun/clients
