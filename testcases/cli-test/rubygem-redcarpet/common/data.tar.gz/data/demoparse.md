A ==simple== fixture file -- with a [link](https://github.com).
