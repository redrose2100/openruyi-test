set(CMAKE_HOST_SYSTEM "Linux-5.10.0-60.43.0.72.oe2203.x86_64")
set(CMAKE_HOST_SYSTEM_NAME "Linux")
set(CMAKE_HOST_SYSTEM_VERSION "5.10.0-60.43.0.72.oe2203.x86_64")
set(CMAKE_HOST_SYSTEM_PROCESSOR "x86_64")

include("/root/mugen/testcases/cli-test/meson/common/0.59/test_6/builddir/subprojects/cmMod/__CMake_build/CMakeMesonToolchainFile.cmake")

set(CMAKE_SYSTEM "Linux-5.10.0-60.43.0.72.oe2203.x86_64")
set(CMAKE_SYSTEM_NAME "Linux")
set(CMAKE_SYSTEM_VERSION "5.10.0-60.43.0.72.oe2203.x86_64")
set(CMAKE_SYSTEM_PROCESSOR "x86_64")

set(CMAKE_CROSSCOMPILING "FALSE")

set(CMAKE_SYSTEM_LOADED 1)
