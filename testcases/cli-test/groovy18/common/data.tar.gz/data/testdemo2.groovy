 #!/usr/bin/env groovy
 prompt = '\n> '
 print 'Enter text including a digit:' + prompt
 System.in.eachLine{ line ->
                                                
     if (line =~ '\\d') println "Read: $line"   
     else System.err.println 'No digit found.'  
 }
