/*
    使用 groovy Script.groovy arg0 arg1 命令
    执行该 Script.groovy 脚本
    在 Groovy 脚本后面带上 arg0 和 arg1 参数
    在 Groovy 脚本中 , 可以通过 args 获取参数
    这是一个字符串数组 String[] 类型的
 /

// 打印 Groovy 脚本参数
pritln "type : ${args.class} , args : ${args}"
