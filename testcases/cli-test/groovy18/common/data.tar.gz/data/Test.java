class Test{
    String name;
    String cls;
    
    public void setName(String name){
        this.name = name;
    }
    public void setCls(String cls){
        this.cls =  cls;
    }

    public String getName(){
        return this.name;
    }
    public String getCls(){
        return this.cls;
    }
}
