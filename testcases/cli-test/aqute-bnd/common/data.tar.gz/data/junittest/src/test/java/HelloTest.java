public class HelloTest {
	JUnitFrameworkBuilder   builder     = new JUnitFrameworkBuilder();
	JUnitFramework          framework = builder.runfw("org.apache.felix.framework");

	    public static class Hello implements BundleActivator {
        static Semaphore semaphore = new Semaphore(0);

        @Override
        public void start(BundleContext context) throws Exception {
            System.out.println("Hello");
            semaphore.release();
        }

        @Override
        public void stop(BundleContext context) throws Exception {
            System.out.println("Goodbye");
            semaphore.release();
        }
    }

	@Test
    public void testActivator() throws BundleException {
        Bundle hello = framework.bundle()
            .bundleActivator(Hello.class)
            .start();

        assertTrue(Hello.semaphore.tryAcquire());
        assertFalse(Hello.semaphore.tryAcquire());

        hello.stop();
        assertTrue(Hello.semaphore.tryAcquire());

    }
}
