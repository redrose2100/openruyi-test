#!/bin/bash
expect <<EOF > tmp.txt
spawn birdc
expect "bird>" {send "echo all\n"}
send "quit\n"
expect eof
EOF
