#!/usr/bin/expect
spawn cvs -d :ext:cvsroot@10.208.134.178:/home/workspace/mugen/testcases/cli-test/cvs/cvs_test/cvs_init_dir  checkout myProject
expect "password: "
send "cvs\r"
expect eof
exit